import React, { useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { StatusBar } from 'expo-status-bar';
import * as SecureStore from 'expo-secure-store';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createOwnerAccount, signInOwner, changeOwnerPassword, getOwnerAccount } from './src/lib/ownerAuth';
import { loadMyProfiles, saveMyProfiles } from './src/lib/myProfiles';
import * as ImagePicker from 'expo-image-picker';
import { Image } from 'react-native';
import { View, Text, TextInput, TouchableOpacity, ScrollView, StyleSheet, Alert, Linking, Platform } from 'react-native';

function showAlert(title, message = '', buttons) {
  if (Platform.OS === 'web') {
    if (buttons && buttons.length > 1) {
      if (typeof window !== 'undefined' && window.confirm(`${title}\n\n${message}`)) {
        const destructive = buttons.find(b => b.style === 'destructive') || buttons[buttons.length - 1];
        destructive?.onPress?.();
      }
    } else if (typeof window !== 'undefined') { window.alert(message ? `${title}\n\n${message}` : title); }
    return;
  }
  Alert.alert(title, message, buttons);
}
import { demoProfiles } from './src/data/demoProfiles';
import { isFacebookProfileUrl } from './src/lib/profileUrl';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();
const BLUE = '#0866FF';
const NAVY = '#102A56';
const PALE = '#F0F6FF';

function Button({ title, onPress, secondary = false }) {
  return <TouchableOpacity onPress={onPress} style={[styles.button, secondary && styles.secondaryButton]}>
    <Text style={[styles.buttonText, secondary && styles.secondaryButtonText]}>{title}</Text>
  </TouchableOpacity>;
}
function Brand({ small = false }) {
  return <View style={[styles.brandMark, small && { width: 42, height: 42, borderRadius: 21 }]}>
    <Ionicons name="chatbubble-ellipses" size={small ? 23 : 42} color="white" />
  </View>;
}
function Field({ value, onChangeText, placeholder, secureTextEntry = false, autoCapitalize = 'none' }) {
  return <TextInput value={value} onChangeText={onChangeText} placeholder={placeholder}
    placeholderTextColor="#8292AA" secureTextEntry={secureTextEntry} autoCapitalize={autoCapitalize}
    style={styles.input} />;
}
function SignInScreen({ onSignedIn }) {
  const [mode, setMode] = useState('loading');
  const [name, setName] = useState('Evelyn Taylor');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [show, setShow] = useState(false);
  React.useEffect(() => { getOwnerAccount().then(account => setMode(account ? 'signin' : 'setup')).catch(() => setMode('setup')); }, []);
  const submit = async () => {
    try {
      if (mode === 'setup') {
        if (password !== confirmPassword) return showAlert('Passwords do not match', 'Enter the same password twice.');
        const result = await createOwnerAccount({ name, email, password });
        if (!result.ok) return showAlert('Account not created', result.message);
        onSignedIn(result.user);
      } else {
        const result = await signInOwner(email, password);
        if (!result.ok) return showAlert('Sign-in failed', result.message);
        onSignedIn(result.user);
      }
    } catch (e) { showAlert('Unable to continue', 'Secure storage is unavailable. Update the app and try again.'); }
  };
  if (mode === 'loading') return <View style={styles.centerScreen}><Brand/><Text style={styles.bodyCenter}>Checking private owner access…</Text></View>;
  return <ScrollView contentContainerStyle={styles.centerScreen} keyboardShouldPersistTaps="handled">
    <Brand />
    <Text style={styles.heroTitle}>Meta Profile Finder Chat</Text>
    <Text style={styles.subtitle}>{mode === 'setup' ? 'Create your private owner login' : 'Private owner sign-in'}</Text>
    <Text style={styles.bodyCenter}>{mode === 'setup' ? 'Create the only owner account for this app on this device. There is no shared default password.' : 'Only the email and password you registered can open this app.'}</Text>
    <View style={styles.form}>
      {mode === 'setup' && <><Text style={styles.label}>Owner name</Text><Field value={name} onChangeText={setName} placeholder="Evelyn Taylor" autoCapitalize="words"/></>}
      <Text style={styles.label}>Owner email</Text>
      <Field value={email} onChangeText={setEmail} placeholder="Your private email" autoCapitalize="none" />
      <Text style={styles.label}>Password</Text>
      <Field value={password} onChangeText={setPassword} placeholder="At least 12 characters" secureTextEntry={!show} />
      {mode === 'setup' && <><Text style={styles.label}>Confirm password</Text><Field value={confirmPassword} onChangeText={setConfirmPassword} placeholder="Enter password again" secureTextEntry={!show}/></>}
      <TouchableOpacity onPress={() => setShow(!show)}><Text style={styles.inlineLink}>{show ? 'Hide password' : 'Show password'}</Text></TouchableOpacity>
      <Button title={mode === 'setup' ? 'Create private owner account' : 'Sign in securely'} onPress={submit} />
      <View style={styles.demoNotice}><Ionicons name="shield-checkmark-outline" size={20} color={BLUE} /><Text style={styles.demoText}>No default login is enabled. {Platform.OS === 'web' ? 'This web version stores account data in this browser and it is not encrypted like iPhone Keychain. Do not use sensitive information until server-backed authentication is added.' : 'Credentials are stored in this device’s encrypted secure storage. This is device-level protection, not a cloud account or a guarantee against someone who controls your unlocked device.'}</Text></View>
    </View>
  </ScrollView>;
}
function HomeScreen({ navigation }) {
  const [query, setQuery] = useState('');
  const [country, setCountry] = useState('All countries');
  const [results, setResults] = useState(null);
  const search = () => {
    if (query.trim() && !isFacebookProfileUrl(query.trim())) {
      return showAlert('Check the link', 'Enter a valid facebook.com profile URL, for example https://www.facebook.com/jane.demo');
    }
    const q = query.trim().toLowerCase();
    let found = demoProfiles.filter(p => (!q || p.url.toLowerCase().includes(q) || p.name.toLowerCase().includes(q)) &&
      (country === 'All countries' || p.country === country));
    setResults(found);
  };
  return <ScrollView style={styles.screen} contentContainerStyle={styles.content}>
    <Text style={styles.pageTitle}>Find a profile</Text>
    <Text style={styles.body}>Search local demo profiles or paste a Facebook profile link.</Text>
    <Field value={query} onChangeText={setQuery} placeholder="Paste a Facebook profile link" />
    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginVertical: 10 }}>
      {['All countries', 'United States', 'Canada', 'Australia', 'United Kingdom', 'France'].map(c =>
        <TouchableOpacity key={c} onPress={() => setCountry(c)} style={[styles.chip, country === c && styles.chipActive]}>
          <Text style={[styles.chipText, country === c && { color: 'white' }]}>{c}</Text>
        </TouchableOpacity>)}
    </ScrollView>
    <Button title="Search demo profiles" onPress={search} />
    <View style={styles.infoCard}><Ionicons name="shield-checkmark-outline" size={22} color={BLUE}/>
      <Text style={styles.infoText}>Demo mode searches sample records only. It does not query Facebook or reveal private information.</Text>
    </View>
    {(results || demoProfiles).map(profile => <View key={profile.id} style={styles.profileCard}>
      <View style={styles.avatar}><Text style={styles.avatarText}>{profile.name.split(' ').map(n => n[0]).join('')}</Text></View>
      <View style={{ flex: 1 }}>
        <Text style={styles.profileName}>{profile.name}</Text>
        <Text style={styles.muted}>{profile.country} · {profile.locked ? 'Limited visibility' : 'Demo profile'}</Text>
        <Text numberOfLines={1} style={styles.urlText}>{profile.url}</Text>
        <View style={styles.cardButtons}>
          <TouchableOpacity style={styles.smallPrimary} onPress={() => navigation.navigate('Profile', { profile })}><Text style={styles.smallPrimaryText}>View Profile</Text></TouchableOpacity>
          <TouchableOpacity style={styles.smallOutline} onPress={() => navigation.navigate('Conversation', { profile })}><Text style={styles.smallOutlineText}>Message demo</Text></TouchableOpacity>
        </View>
      </View>
    </View>)}
    <Text style={styles.muted}>All sample names and records are fictional.</Text>
  </ScrollView>;
}
function ProfileScreen({ route, navigation }) {
  const p = route.params?.profile || demoProfiles[0];
  return <ScrollView style={styles.screen} contentContainerStyle={styles.content}>
    <View style={styles.cover}><Brand small /></View>
    <View style={styles.profileHero}>
      <View style={[styles.avatar, { width: 82, height: 82, borderRadius: 41 }]}><Text style={[styles.avatarText, { fontSize: 25 }]}>{p.name.split(' ').map(n => n[0]).join('')}</Text></View>
      <Text style={styles.pageTitle}>{p.name}</Text>
      <Text style={styles.muted}>{p.country} · Demo record</Text>
    </View>
    <Button title="Open Facebook" onPress={() => Linking.openURL(p.url).catch(() => showAlert('Unable to open link'))} />
    <Button title="Open demo conversation" secondary onPress={() => navigation.navigate('Conversation', { profile: p })} />
    {p.locked ? <View style={styles.lockedCard}>
      <Ionicons name="lock-closed" size={42} color={BLUE} />
      <Text style={styles.lockTitle}>Profile is locked</Text>
      <Text style={styles.bodyCenter}>Some profile information is unavailable. Open Facebook to review the options available to you.</Text>
    </View> : <View style={styles.infoCard}><Ionicons name="information-circle-outline" size={22} color={BLUE}/><Text style={styles.infoText}>{p.about}</Text></View>}
    <Text style={styles.muted}>This is a local demo profile, not verified live Facebook data.</Text>
  </ScrollView>;
}
function ConversationScreen({ route }) {
  const profile = route.params?.profile || { id: 'owner-evelyn', name: 'Evelyn Taylor' };
  const storageKey = `mpfc_local_chat_${String(profile.id || 'owner-evelyn')}`;
  const [messages, setMessages] = useState([]);
  const [draft, setDraft] = useState('');
  const [loaded, setLoaded] = useState(false);
  React.useEffect(() => {
    let active = true;
    AsyncStorage.getItem(storageKey).then(raw => {
      if (!active) return;
      if (raw) { try { setMessages(JSON.parse(raw)); } catch { setMessages([]); } }
      setLoaded(true);
    }).catch(() => setLoaded(true));
    return () => { active = false; };
  }, [storageKey]);
  const send = async () => {
    const text = draft.trim();
    if (!text || !loaded) return;
    const next = [...messages, { id: `${Date.now()}`, from: 'me', text, createdAt: new Date().toISOString() }];
    try {
      await AsyncStorage.setItem(storageKey, JSON.stringify(next));
      setMessages(next); setDraft('');
    } catch { showAlert('Could not save message', 'Check available device storage and try again.'); }
  };
  return <View style={styles.screen}>
    <View style={styles.chatHeader}><View style={styles.avatarSmall}><Text style={styles.avatarText}>{(profile.name || 'E')[0]}</Text></View>
      <View><Text style={styles.profileName}>{profile.name || 'Evelyn Taylor'}</Text><Text style={styles.muted}>Private app chat · saved on this iPhone</Text></View>
    </View>
    <ScrollView style={{ flex: 1, padding: 16 }}>
      {!messages.length && <Text style={styles.bodyCenter}>Start a conversation. Messages are stored locally on this device; they are not delivered to Facebook or another phone.</Text>}
      {messages.map((m, i) => <View key={m.id || i} style={[styles.bubble, m.from === 'me' ? styles.myBubble : styles.theirBubble]}>
        <Text style={{ color: m.from === 'me' ? 'white' : NAVY }}>{m.text}</Text>
      </View>)}
    </ScrollView>
    <View style={styles.composer}><TextInput value={draft} onChangeText={setDraft} placeholder="Write a message..." editable={loaded} style={styles.composerInput}/>
      <TouchableOpacity onPress={send} disabled={!loaded || !draft.trim()} style={[styles.sendButton, (!loaded || !draft.trim()) && { opacity: 0.5 }]}><Ionicons name="send" size={20} color="white"/></TouchableOpacity></View>
    <Text style={styles.footerNote}>Local prototype only · no remote delivery or end-to-end encryption</Text>
  </View>;
}
function MessagesScreen({ navigation }) {
  const owner = { id: 'owner-evelyn', name: 'Evelyn Taylor' };
  const [lastMessage, setLastMessage] = useState('');
  React.useEffect(() => {
    const load = () => AsyncStorage.getItem('mpfc_local_chat_owner-evelyn').then(raw => {
      if (!raw) return setLastMessage('No messages yet');
      try { const list = JSON.parse(raw); setLastMessage(list.length ? list[list.length - 1].text : 'No messages yet'); } catch { setLastMessage('No messages yet'); }
    }).catch(() => setLastMessage('Messages unavailable'));
    load();
    const unsubscribe = navigation.addListener('focus', load);
    return unsubscribe;
  }, [navigation]);
  return <ScrollView style={styles.screen} contentContainerStyle={styles.content}>
    <Text style={styles.pageTitle}>Messages</Text>
    <View style={styles.infoCard}><Ionicons name="chatbubbles-outline" size={24} color={BLUE}/><Text style={styles.infoText}>This is a local app inbox. Messages do not sync to other devices or Facebook. Remote, secure messaging requires a deployed backend and authenticated participants.</Text></View>
    <TouchableOpacity style={styles.messageRow} onPress={() => navigation.navigate('Conversation', { profile: owner })}>
      <View style={styles.avatar}><Text style={styles.avatarText}>ET</Text></View>
      <View style={{ flex: 1 }}><Text style={styles.profileName}>Evelyn Taylor · My inbox</Text><Text numberOfLines={1} style={styles.muted}>{lastMessage}</Text></View>
      <Ionicons name="chevron-forward" color={BLUE} size={20}/>
    </TouchableOpacity>
    <Text style={styles.sectionTitle}>Demo profiles</Text>
    {demoProfiles.map(p => <TouchableOpacity key={p.id} style={styles.messageRow} onPress={() => navigation.navigate('Conversation', { profile: p })}>
      <View style={styles.avatar}><Text style={styles.avatarText}>{p.name[0]}</Text></View>
      <View style={{ flex: 1 }}><Text style={styles.profileName}>{p.name}</Text><Text style={styles.muted}>Local demo thread only</Text></View>
      <Ionicons name="chevron-forward" color={BLUE} size={20}/>
    </TouchableOpacity>)}
  </ScrollView>;
}
function SettingsScreen({ user, onSignOut, navigation }) {
  const [ownerPhoto, setOwnerPhoto] = useState(null);
  const [displayName, setDisplayName] = useState(user?.name || 'Evelyn Taylor');
  const [friendsCount, setFriendsCount] = useState('789');
  const [facebookProfileUrl, setFacebookProfileUrl] = useState('');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [savingPassword, setSavingPassword] = useState(false);
  React.useEffect(() => {
    AsyncStorage.getItem('mpfc_owner_photo_uri').then(async v => {
      if (v) setOwnerPhoto(v);
      else {
        // Migrate older installs that stored the image URI in SecureStore.
        const legacy = await SecureStore.getItemAsync('mpfc_owner_photo_uri').catch(() => null);
        if (legacy) { await AsyncStorage.setItem('mpfc_owner_photo_uri', legacy); setOwnerPhoto(legacy); }
      }
    }).catch(() => {});
    // Display preferences are ordinary app data, so keep them in AsyncStorage.
    // Migrate values written by earlier builds from SecureStore for existing installs.
    Promise.all([AsyncStorage.getItem('mpfc_display_name'), AsyncStorage.getItem('mpfc_friends_count'), AsyncStorage.getItem('mpfc_facebook_profile_url')])
      .then(async ([savedName, savedCount, savedProfileUrl]) => {
        const legacyName = savedName ? null : await SecureStore.getItemAsync('mpfc_display_name').catch(() => null);
        const legacyCount = savedCount ? null : await SecureStore.getItemAsync('mpfc_friends_count').catch(() => null);
        if (savedName || legacyName) setDisplayName(savedName || legacyName);
        if (savedCount || legacyCount) setFriendsCount(savedCount || legacyCount);
        if (savedProfileUrl) setFacebookProfileUrl(savedProfileUrl);
        if (legacyName) await AsyncStorage.setItem('mpfc_display_name', legacyName);
        if (legacyCount) await AsyncStorage.setItem('mpfc_friends_count', legacyCount);
      }).catch(() => {});
  }, []);
  const savePublicProfile = async () => {
    const cleanName = displayName.trim();
    const cleanCount = friendsCount.trim();
    const cleanProfileUrl = facebookProfileUrl.trim();
    if (!cleanName) return showAlert('Name required', 'Enter a display name.');
    if (!/^\d{1,9}$/.test(cleanCount)) return showAlert('Check friends count', 'Enter a whole number between 0 and 999999999.');
    if (cleanProfileUrl && !isFacebookProfileUrl(cleanProfileUrl)) return showAlert('Check Facebook profile link', 'Use your public HTTPS Facebook profile URL, such as https://www.facebook.com/your.username');
    try {
      await Promise.all([
        AsyncStorage.setItem('mpfc_display_name', cleanName),
        AsyncStorage.setItem('mpfc_friends_count', cleanCount),
        AsyncStorage.setItem('mpfc_facebook_profile_url', cleanProfileUrl)
      ]);
      showAlert('Profile updated', 'Your visitor profile preview has been updated on this device.');
    } catch { showAlert('Could not save', 'Please try again.'); }
  };
  const chooseOwnerPhoto = async () => {
    try {
      if (Platform.OS !== 'web') {
        const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
        if (!permission.granted) return showAlert('Photo permission needed', 'Allow photo-library access to choose your profile picture.');
      }
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ['images'], allowsEditing: true, aspect: [1, 1], quality: 0.85
      });
      if (result.canceled || !result.assets?.[0]?.uri) return;
      const uri = result.assets[0].uri;
      await AsyncStorage.setItem('mpfc_owner_photo_uri', uri);
      setOwnerPhoto(uri);
      showAlert('Profile picture updated', 'Your owner profile picture has been changed on this device.');
    } catch {
      showAlert('Could not choose picture', 'Check photo permissions and available device storage, then try again.');
    }
  };
  const changePassword = async () => {
    if (!currentPassword || !newPassword || !confirmPassword) return showAlert('Missing information', 'Complete all three password fields.');
    if (newPassword.length < 12) return showAlert('Password too short', 'Use at least 12 characters.');
    if (newPassword !== confirmPassword) return showAlert('Passwords do not match', 'Enter the same new password twice.');
    setSavingPassword(true);
    try {
      const result = await changeOwnerPassword(currentPassword, newPassword);
      if (!result.ok) { showAlert('Could not change password', result.message); return; }
      setCurrentPassword(''); setNewPassword(''); setConfirmPassword('');
      showAlert('Password changed', 'Your owner password has been updated securely on this device.');
    } catch (e) {
      showAlert('Could not change password', 'Please try again on this device.');
    } finally { setSavingPassword(false); }
  };
  return <ScrollView style={styles.screen} contentContainerStyle={styles.content}>
    <Text style={styles.pageTitle}>Private Settings</Text>
    <View style={styles.ownerCard}>
      <TouchableOpacity onPress={chooseOwnerPhoto} accessibilityLabel="Upload or change profile picture" style={styles.photoUpload}>
        {ownerPhoto ? <Image source={{ uri: ownerPhoto }} style={styles.ownerPhoto} /> : <View style={styles.photoPlaceholder}><Ionicons name="person" size={30} color={BLUE}/></View>}
        <View style={styles.photoBadge}><Ionicons name="camera" size={14} color="white"/></View>
      </TouchableOpacity>
      <View style={{ flex: 1 }}>
        <Text style={styles.profileName}>{displayName || user?.name || 'Evelyn Taylor'}</Text>
        <Text style={styles.muted}>Private owner account · This device</Text>
        <TouchableOpacity onPress={chooseOwnerPhoto}><Text style={styles.inlineLink}>Upload / Change picture</Text></TouchableOpacity>
      </View>
    </View>
    <Text style={styles.sectionTitle}>Visitor profile display</Text>
    <Text style={styles.body}>Edit the name shown on your app profile preview. This app profile is separate from Facebook; no Facebook account is created.</Text>
    <Text style={styles.label}>Display name</Text>
    <Field value={displayName} onChangeText={setDisplayName} placeholder="Your display name" autoCapitalize="words" />
        <Text style={styles.label}>Your Facebook profile link</Text>
    <Field value={facebookProfileUrl} onChangeText={setFacebookProfileUrl} placeholder="https://www.facebook.com/your.username" autoCapitalize="none" />
    <Text style={styles.muted}>This opens your real Facebook profile in Facebook or a browser. It does not sign in to Facebook or sync profile data.</Text>
    <Button title="Save visitor profile" onPress={savePublicProfile} />
    <Button title="Preview visitor screen" secondary onPress={() => navigation.navigate('VisitorProfile', { displayName: displayName.trim() || user?.name || 'Evelyn Taylor', friendsCount: friendsCount.trim() || '789', ownerPhoto, facebookProfileUrl: facebookProfileUrl.trim() })} />
    <Text style={styles.sectionTitle}>Change your password</Text>
    <Text style={styles.body}>Use at least 12 characters for your new password.</Text>
    <Text style={styles.label}>Current password</Text>
    <Field value={currentPassword} onChangeText={setCurrentPassword} placeholder="Enter current password" secureTextEntry />
    <Text style={styles.label}>New password</Text>
    <Field value={newPassword} onChangeText={setNewPassword} placeholder="At least 12 characters" secureTextEntry />
    <Text style={styles.label}>Confirm new password</Text>
    <Field value={confirmPassword} onChangeText={setConfirmPassword} placeholder="Enter new password again" secureTextEntry />
    <Button title={savingPassword ? 'Saving...' : 'Change password'} onPress={changePassword} />
    <View style={styles.infoCard}><Ionicons name="shield-checkmark-outline" size={22} color={BLUE}/><Text style={styles.infoText}>{Platform.OS === 'web' ? 'The web version stores account data in this browser, not encrypted server storage. Do not use sensitive information until server-backed authentication is added.' : "This prototype stores the password in your phone's secure storage. It is device-local demo protection, not server-backed account security. Use a real authentication provider and multi-factor authentication before public release."}</Text></View>
    <Text style={styles.sectionTitle}>Meta integration</Text>
    <View style={styles.infoCard}><Ionicons name="link-outline" size={22} color={BLUE}/><Text style={styles.infoText}>Not connected. Configure a Meta developer app, approved permissions, and a secure backend before enabling real services.</Text></View>
    <Text style={styles.sectionTitle}>Privacy and security</Text>
    {['Owner sign-in is device-local', 'No Facebook password collection', 'No profile scraping or privacy bypass', 'Local chat stays on this iPhone and is not end-to-end encrypted'].map(x => <View key={x} style={styles.checkRow}><Ionicons name="checkmark-circle" color="#16834A" size={20}/><Text style={styles.body}>{x}</Text></View>)}
    <Button title="Sign out" secondary onPress={onSignOut}/>
  </ScrollView>;
}
function VisitorProfileScreen({ route, navigation }) {
  const [displayName, setDisplayName] = useState(route.params?.displayName || 'Evelyn Taylor');
  const [friendsCount, setFriendsCount] = useState(route.params?.friendsCount || '789');
  const [ownerPhoto, setOwnerPhoto] = useState(route.params?.ownerPhoto || null);
  const [facebookProfileUrl, setFacebookProfileUrl] = useState(route.params?.facebookProfileUrl || '');
  React.useEffect(() => {
    // Refresh when the Settings screen opens this route again with updated preview values.
    if (route.params && ['displayName', 'friendsCount', 'ownerPhoto', 'facebookProfileUrl'].some(key => Object.prototype.hasOwnProperty.call(route.params, key))) {
      if (route.params.displayName) setDisplayName(route.params.displayName);
      if (route.params.friendsCount) setFriendsCount(route.params.friendsCount);
      if (Object.prototype.hasOwnProperty.call(route.params, 'ownerPhoto')) setOwnerPhoto(route.params.ownerPhoto || null);
      if (Object.prototype.hasOwnProperty.call(route.params, 'facebookProfileUrl')) setFacebookProfileUrl(route.params.facebookProfileUrl || '');
      return;
    }
    // AsyncStorage is the canonical store; read legacy SecureStore values as a migration fallback.
    Promise.all([AsyncStorage.getItem('mpfc_display_name'), AsyncStorage.getItem('mpfc_friends_count'), AsyncStorage.getItem('mpfc_owner_photo_uri'), AsyncStorage.getItem('mpfc_facebook_profile_url')])
      .then(async ([name, count, photo, profileUrl]) => {
        const legacyName = name ? null : await SecureStore.getItemAsync('mpfc_display_name').catch(() => null);
        const legacyCount = count ? null : await SecureStore.getItemAsync('mpfc_friends_count').catch(() => null);
        if (name || legacyName) setDisplayName(name || legacyName);
        if (count || legacyCount) setFriendsCount(count || legacyCount);
        if (photo) setOwnerPhoto(photo);
        if (profileUrl) setFacebookProfileUrl(profileUrl);
        if (legacyName) await AsyncStorage.setItem('mpfc_display_name', legacyName);
        if (legacyCount) await AsyncStorage.setItem('mpfc_friends_count', legacyCount);
      }).catch(() => {});
  }, [route.params]);
  const initials = (displayName || 'Evelyn Taylor').split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase();
  return <ScrollView style={styles.screen} contentContainerStyle={styles.content}>
    <View style={styles.cover}><Brand small /></View>
    <View style={styles.profileHero}>
      {ownerPhoto ? <Image source={{ uri: ownerPhoto }} style={[styles.avatar, { width: 86, height: 86, borderRadius: 43 }]} /> : <View style={[styles.avatar, { width: 86, height: 86, borderRadius: 43 }]}><Text style={[styles.avatarText, { fontSize: 26 }]}>{initials}</Text></View>}
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, marginTop: 12 }}>
        <Text style={[styles.pageTitle, { textAlign: 'center', flexShrink: 1 }]}>{displayName || 'Evelyn Taylor'}</Text>
      </View>
      <Text style={styles.muted}>Evelyn Taylor · App profile</Text>
      <Text style={styles.bodyCenter}>Message Evelyn privately in this app</Text>
    </View>
    <Button title="Message" onPress={() => navigation.navigate('Conversation', { profile: { id: 'owner-evelyn', name: displayName || 'Evelyn Taylor', isOwner: true } })} />
    <View style={styles.infoCard}><Ionicons name="information-circle-outline" size={22} color={BLUE}/><Text style={styles.infoText}>This is your app profile, not a Facebook account. The Message button opens the app's local chat screen. Until a secure backend is deployed and users authenticate, messages remain on this iPhone and are not delivered to other people or Facebook.</Text></View>
  </ScrollView>;
}

function MyProfilesScreen({ navigation }) {
  const [profiles, setProfiles] = useState([]);
  const [name, setName] = useState('');
  const [url, setUrl] = useState('');
  const [country, setCountry] = useState('United States');
  const [about, setAbout] = useState('');
  const [loading, setLoading] = useState(true);
  React.useEffect(() => { loadMyProfiles().then(setProfiles).finally(() => setLoading(false)); }, []);
  const addProfile = async () => {
    if (!name.trim() || !url.trim()) return showAlert('Missing details', 'Enter a profile name and Facebook profile URL.');
    if (!isFacebookProfileUrl(url.trim())) return showAlert('Check the link', 'Enter a valid facebook.com profile URL.');
    if (profiles.length >= 3) return showAlert('Profile limit reached', 'You can create up to 3 saved profiles. Delete one before adding another.');
    const next = [...profiles, { id: `${Date.now()}`, name: name.trim(), url: url.trim(), country, about: about.trim() || 'Personal saved profile', locked: false, isPersonalSaved: true }];
    try { await saveMyProfiles(next); setProfiles(next); setName(''); setUrl(''); setAbout(''); showAlert('Profile saved', `Saved profile ${next.length} of 3.`); }
    catch { showAlert('Could not save', 'Please try again.'); }
  };
  const removeProfile = (id) => showAlert('Delete saved profile?', 'This removes the profile from this device.', [{ text: 'Cancel', style: 'cancel' }, { text: 'Delete', style: 'destructive', onPress: async () => { const next = profiles.filter(p => p.id !== id); await saveMyProfiles(next); setProfiles(next); } }]);
  return <ScrollView style={styles.screen} contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
    <Text style={styles.pageTitle}>My Saved Profiles</Text>
    <Text style={styles.body}>Create and manage up to 3 profile shortcuts. These are saved locally; adding a profile does not reveal private Facebook information or connect messaging.</Text>
    <View style={styles.infoCard}><Ionicons name="shield-checkmark-outline" size={22} color={BLUE}/><Text style={styles.infoText}>{profiles.length} of 3 profile slots used</Text></View>
    {profiles.map((p, i) => <View key={p.id} style={styles.profileCard}><View style={styles.avatar}><Text style={styles.avatarText}>{p.name.split(' ').map(n=>n[0]).join('').slice(0,2)}</Text></View><View style={{flex:1}}><Text style={styles.profileName}>{i+1}. {p.name}</Text><Text style={styles.muted}>{p.country}</Text><Text numberOfLines={1} style={styles.urlText}>{p.url}</Text><View style={styles.cardButtons}><TouchableOpacity style={styles.smallPrimary} onPress={() => navigation.navigate('Profile', { profile: p })}><Text style={styles.smallPrimaryText}>View</Text></TouchableOpacity><TouchableOpacity style={styles.smallOutline} onPress={() => Linking.openURL(p.url).catch(()=>showAlert('Unable to open link'))}><Text style={styles.smallOutlineText}>Open Facebook</Text></TouchableOpacity><TouchableOpacity style={styles.smallOutline} onPress={() => removeProfile(p.id)}><Text style={styles.smallOutlineText}>Delete</Text></TouchableOpacity></View></View></View>)}
    <Text style={styles.sectionTitle}>Create a profile ({profiles.length}/3)</Text>
    <Text style={styles.label}>Profile name</Text><Field value={name} onChangeText={setName} placeholder="Name or label" autoCapitalize="words"/>
    <Text style={styles.label}>Facebook profile URL</Text><Field value={url} onChangeText={setUrl} placeholder="https://www.facebook.com/..." autoCapitalize="none"/>
    <Text style={styles.label}>Country</Text><Field value={country} onChangeText={setCountry} placeholder="Country" autoCapitalize="words"/>
    <Text style={styles.label}>Notes (optional)</Text><Field value={about} onChangeText={setAbout} placeholder="Add a short note" autoCapitalize="sentences"/>
    <Button title={profiles.length >= 3 ? 'All 3 profile slots are full' : 'Save profile'} onPress={addProfile}/>
    {loading && <Text style={styles.muted}>Loading saved profiles…</Text>}
  </ScrollView>;
}

function Tabs({ user, onSignOut }) {
  return <Tab.Navigator screenOptions={({ route }) => ({
    headerStyle: { backgroundColor: BLUE }, headerTintColor: 'white',
    tabBarActiveTintColor: BLUE, tabBarInactiveTintColor: '#78879D',
    tabBarIcon: ({ color, size }) => {
      const names = { Search: 'search', MyProfiles: 'people', Messages: 'chatbubbles', Settings: 'settings' };
      return <Ionicons name={names[route.name] || 'home'} size={size} color={color}/>;
    }
  })}>
    <Tab.Screen name="Search" component={HomeScreen} options={{ title: 'Profile Search' }}/><Tab.Screen name="MyProfiles" component={MyProfilesScreen} options={{ title: 'My Profiles', tabBarLabel: 'My Profiles', tabBarIcon: ({ color, size }) => <Ionicons name="people" size={size} color={color}/> }}/>
    <Tab.Screen name="Messages" component={MessagesScreen} options={{ title: 'Messages' }}/>
    <Tab.Screen name="Settings" options={{ title: 'Settings' }}>{props => <SettingsScreen {...props} user={user} onSignOut={onSignOut}/>}</Tab.Screen>
  </Tab.Navigator>;
}
export default function App() {
  const [user, setUser] = useState(null);
  return <NavigationContainer>
    <StatusBar style="light"/>
    <Stack.Navigator screenOptions={{ headerStyle: { backgroundColor: BLUE }, headerTintColor: 'white' }}>
      {!user ? <Stack.Screen name="SignIn" options={{ headerShown: false }}>
        {() => <SignInScreen onSignedIn={setUser}/>}
      </Stack.Screen> : <>
        <Stack.Screen name="Main" options={{ headerShown: false }}>
          {() => <Tabs user={user} onSignOut={() => setUser(null)}/>}
        </Stack.Screen>
        <Stack.Screen name="Profile" component={ProfileScreen} options={{ title: 'View Profile' }}/>
        <Stack.Screen name="Conversation" component={ConversationScreen} options={{ title: 'Demo Messages' }}/><Stack.Screen name="VisitorProfile" component={VisitorProfileScreen} options={{ title: 'Visitor Profile Preview' }}/>
      </>}
    </Stack.Navigator>
  </NavigationContainer>;
}
const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#F6F9FE' }, content: { padding: 18, paddingBottom: 34 },
  centerScreen: { flexGrow: 1, justifyContent: 'center', padding: 24, backgroundColor: '#F6F9FE' },
  brandMark: { width: 84, height: 84, borderRadius: 42, backgroundColor: BLUE, alignItems: 'center', justifyContent: 'center', alignSelf: 'center', marginBottom: 18 },
  heroTitle: { fontSize: 28, lineHeight: 34, color: BLUE, fontWeight: '800', textAlign: 'center' },
  subtitle: { fontSize: 18, color: NAVY, fontWeight: '700', textAlign: 'center', marginTop: 18 },
  body: { fontSize: 14, color: '#52637D', lineHeight: 21, marginTop: 6 },
  bodyCenter: { fontSize: 14, color: '#52637D', lineHeight: 21, textAlign: 'center', marginTop: 10 },
  form: { marginTop: 28 }, label: { fontWeight: '700', color: NAVY, marginBottom: 8, marginTop: 10 },
  input: { borderWidth: 1, borderColor: '#D7E3F5', backgroundColor: 'white', borderRadius: 12, paddingHorizontal: 14, paddingVertical: 13, fontSize: 15, color: NAVY, marginTop: 8 },
  button: { backgroundColor: BLUE, padding: 14, borderRadius: 12, alignItems: 'center', marginTop: 14 },
  buttonText: { color: 'white', fontSize: 15, fontWeight: '700' }, secondaryButton: { backgroundColor: 'white', borderWidth: 1, borderColor: '#BCD3F8' },
  secondaryButtonText: { color: BLUE }, inlineLink: { color: BLUE, textAlign: 'right', marginTop: 8 },
  demoNotice: { flexDirection: 'row', gap: 8, backgroundColor: '#EAF3FF', padding: 12, borderRadius: 12, marginTop: 20, alignItems: 'flex-start' },
  demoText: { flex: 1, color: '#405674', fontSize: 12, lineHeight: 18 }, pageTitle: { fontSize: 25, color: NAVY, fontWeight: '800', marginBottom: 4 },
  chip: { borderWidth: 1, borderColor: '#C9D9F2', backgroundColor: 'white', borderRadius: 20, paddingVertical: 8, paddingHorizontal: 12, marginRight: 7 },
  chipActive: { backgroundColor: BLUE, borderColor: BLUE }, chipText: { color: NAVY, fontSize: 12, fontWeight: '600' },
  infoCard: { flexDirection: 'row', gap: 10, alignItems: 'center', backgroundColor: '#EAF3FF', padding: 13, borderRadius: 12, marginVertical: 14 },
  infoText: { flex: 1, color: '#405674', fontSize: 13, lineHeight: 19 }, profileCard: { flexDirection: 'row', backgroundColor: 'white', borderRadius: 16, padding: 13, marginTop: 12, borderWidth: 1, borderColor: '#E0EAF8', gap: 12 },
  avatar: { width: 58, height: 58, borderRadius: 29, backgroundColor: '#D8E8FF', alignItems: 'center', justifyContent: 'center' },
  avatarText: { color: BLUE, fontWeight: '800', fontSize: 19 }, profileName: { fontSize: 15, fontWeight: '800', color: NAVY },
  muted: { color: '#7A8AA3', fontSize: 12, marginTop: 4 }, urlText: { color: '#5A76A0', fontSize: 11, marginTop: 5 },
  cardButtons: { flexDirection: 'row', gap: 7, marginTop: 10, flexWrap: 'wrap' }, smallPrimary: { backgroundColor: BLUE, paddingVertical: 9, paddingHorizontal: 12, borderRadius: 9 },
  smallPrimaryText: { color: 'white', fontWeight: '700', fontSize: 12 }, smallOutline: { borderWidth: 1, borderColor: '#BCD3F8', paddingVertical: 9, paddingHorizontal: 12, borderRadius: 9 },
  smallOutlineText: { color: BLUE, fontWeight: '700', fontSize: 12 }, cover: { height: 105, borderRadius: 16, backgroundColor: BLUE, justifyContent: 'center', alignItems: 'center' },
  profileHero: { alignItems: 'center', marginTop: -8, marginBottom: 18 }, lockedCard: { alignItems: 'center', backgroundColor: '#EAF3FF', borderRadius: 16, padding: 24, marginTop: 22 },
  lockTitle: { color: NAVY, fontSize: 20, fontWeight: '800', marginTop: 12 }, chatHeader: { backgroundColor: 'white', flexDirection: 'row', padding: 14, alignItems: 'center', gap: 12, borderBottomWidth: 1, borderColor: '#E1E9F5' },
  avatarSmall: { width: 42, height: 42, borderRadius: 21, backgroundColor: '#D8E8FF', alignItems: 'center', justifyContent: 'center' },
  bubble: { padding: 12, borderRadius: 16, maxWidth: '85%', marginBottom: 10 }, myBubble: { backgroundColor: BLUE, alignSelf: 'flex-end' },
  theirBubble: { backgroundColor: '#E5ECF5', alignSelf: 'flex-start' }, composer: { flexDirection: 'row', padding: 12, alignItems: 'center', backgroundColor: 'white', gap: 8 },
  composerInput: { flex: 1, backgroundColor: '#F4F7FC', borderRadius: 22, paddingHorizontal: 15, paddingVertical: 11 }, sendButton: { width: 42, height: 42, borderRadius: 21, backgroundColor: BLUE, alignItems: 'center', justifyContent: 'center' },
  footerNote: { textAlign: 'center', color: '#7A8AA3', fontSize: 11, paddingBottom: 8, backgroundColor: 'white' }, messageRow: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: 'white', padding: 14, borderRadius: 14, marginTop: 10 },
  ownerCard: { backgroundColor: 'white', borderRadius: 14, padding: 14, flexDirection: 'row', alignItems: 'center', gap: 14, marginTop: 14 },
  photoUpload: { width: 64, height: 64, borderRadius: 32, position: 'relative' },
  ownerPhoto: { width: 64, height: 64, borderRadius: 32, backgroundColor: '#D8E8FF' },
  photoPlaceholder: { width: 64, height: 64, borderRadius: 32, backgroundColor: '#D8E8FF', alignItems: 'center', justifyContent: 'center' },
  photoBadge: { position: 'absolute', right: -2, bottom: -2, width: 25, height: 25, borderRadius: 13, backgroundColor: BLUE, alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: 'white' },
  appBadge: { width: 21, height: 21, borderRadius: 11, backgroundColor: BLUE, alignItems: 'center', justifyContent: 'center' },
  sectionTitle: { fontSize: 17, color: NAVY, fontWeight: '800', marginTop: 20, marginBottom: 2 }, checkRow: { flexDirection: 'row', gap: 10, alignItems: 'center', paddingVertical: 7 }
});
