# Account and recovery setup — Evelyn Taylor Chat

Intended primary app email: `ishaanburchyfvz@hotmail.com`
Intended recovery email: `willistaylor890@gmail.com`

These addresses are configuration notes only in this source package. They have not been verified, and this app does not currently send email, issue reset links, or verify ownership. Do not rely on the recovery address until a real backend and email provider are configured and both addresses are verified.

## Before enabling account recovery
1. Deploy an HTTPS backend and configure a reputable transactional email provider.
2. Store provider credentials only as server environment variables; never in the mobile app.
3. Implement single-use, short-lived, rate-limited reset tokens and generic responses that do not reveal whether an email has an account.
4. Verify ownership of the primary and recovery addresses, and let the owner remove/update recovery addresses after re-authentication.
5. Add abuse throttling, audit logging, deletion/export controls, and tests before production use.

## Live messages
The current app's messages are stored locally on this iPhone only. This package does not deliver messages to other users or Facebook/Messenger. A production chat backend and authenticated user accounts must be deployed and integrated. Meta messaging access must follow Meta's current product eligibility, permissions, review, and recipient rules. It cannot send to arbitrary personal Facebook inboxes or bypass restrictions.
