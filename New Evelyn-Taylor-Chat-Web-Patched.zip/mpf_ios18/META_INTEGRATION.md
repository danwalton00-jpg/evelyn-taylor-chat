# Real Meta integration: remaining required setup

The app UI is prepared, but live Meta integration cannot be activated from source code alone. You must create/configure a Meta developer app and receive any required permissions/app review. Never put an app secret or long-lived access token in this mobile app.

## Required production architecture

1. Meta developer app configured for the specific supported Meta product/use case.
2. Backend service that handles OAuth callback, validates state, stores tokens securely, and checks owner authorization.
3. Server-side endpoints for only the approved profile/messaging operations.
4. Privacy policy, data deletion process, terms, and app review materials where required.
5. Testing with eligible Meta test accounts/pages before production use.

## Important product limitation

A profile URL does not itself grant access to a Facebook profile's private fields or to arbitrary personal Messenger conversations. Messaging capabilities depend on the specific Meta API, account/page context, recipient eligibility, permissions, and policy constraints. This project intentionally does not scrape profiles or bypass locked profiles.

## Configuration placeholders

Use environment variables on the backend only; do not put real secrets in the Expo client:

- `META_APP_ID`
- `META_APP_SECRET`
- `META_REDIRECT_URI`
- `META_API_VERSION`

Do not add real credentials to this file or commit them to source control. Follow current Meta for Developers documentation for the exact login product, API endpoints, scopes, and review process for your use case.
