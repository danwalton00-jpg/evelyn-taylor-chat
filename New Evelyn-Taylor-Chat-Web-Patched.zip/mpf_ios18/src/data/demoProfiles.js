// Fictional local records for demo UI only. These are not real Facebook users.
export const demoProfiles = [
  { id: 'demo-1', name: 'Jane Demo', country: 'United States', url: 'https://www.facebook.com/jane.demo', locked: true, about: 'Fictional sample profile for demonstrating the profile view.' },
  { id: 'demo-2', name: 'Alex Sample', country: 'Canada', url: 'https://www.facebook.com/alex.sample', locked: false, about: 'Fictional sample profile. No real personal data is shown.' },
  { id: 'demo-3', name: 'Casey Example', country: 'Australia', url: 'https://www.facebook.com/casey.example', locked: false, about: 'Fictional sample profile for interface testing.' },
  { id: 'demo-4', name: 'Taylor Example', country: 'United Kingdom', url: 'https://www.facebook.com/taylor.example', locked: true, about: 'Fictional sample profile for interface testing.' }
];
