Replace app-icon.png and splash.png with your own uploaded logo artwork.
The current app source uses an in-app Messenger-inspired placeholder icon.
