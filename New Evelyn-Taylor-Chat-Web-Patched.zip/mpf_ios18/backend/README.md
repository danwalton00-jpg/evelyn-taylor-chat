# Backend scaffold

This folder adds a server-side foundation for owner-only authentication and the Meta OAuth authorization-code flow. It is intentionally not advertised as production-ready: persistent credential storage, durable password changes, encrypted Meta-token storage, audit logging, and deployment-specific origin configuration still need to be implemented before real use.

## Run locally

1. Install Node.js 20 or newer.
2. `cd backend && npm install`
3. Copy `.env.example` to `.env` and set a strong owner password hash and a random `JWT_SECRET` (at least 32 characters).
4. `npm start`
5. Verify `GET http://localhost:8080/health`.

Generate a bcrypt hash from a terminal in this folder with:

```sh
node -e "const b=require('bcryptjs'); console.log(b.hashSync(process.argv[1],12))" 'use-a-long-unique-password'
```

Never commit `.env`, the Meta app secret, JWT secret, or access tokens. The starter's mobile app still uses its local demo sign-in until its UI is wired to the deployed API; do not treat the local demo gate as production security.

## Meta setup

Create/configure the app in Meta for Developers, add the exact redirect URI, and set `META_APP_ID`, `META_APP_SECRET`, `META_REDIRECT_URI`, and `META_API_VERSION` in the server environment. The initial scope is only `public_profile`. Messenger sending is a separate Page-based integration that normally needs an eligible Facebook Page, `pages_messaging`, Page access token, recipient eligibility, and Meta review. It does not grant access to arbitrary personal inboxes or private profile fields.

Before production: add a persistent database-backed owner account/password-change flow; durable, encrypted Meta-token storage; CSRF/state persistence suitable for multiple server instances; HTTPS; strict CORS/origin allowlists if needed; request logging with secrets redacted; data deletion/privacy-policy endpoints; and tests. Do not expose Meta app secrets or long-lived tokens to the Expo client.
