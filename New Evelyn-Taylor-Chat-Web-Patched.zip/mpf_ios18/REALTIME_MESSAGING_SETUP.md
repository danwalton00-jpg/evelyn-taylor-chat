# Live messaging activation — Evelyn Taylor Chat

## Important status

This project currently saves messages to local device/browser storage. The Expo web build configuration is prepared below, but live messages between different users are **not activated** by this ZIP alone. A shared backend and real authenticated user accounts are required. Do not present local messages as delivered to another person.

## Web deployment configuration included

- Netlify build command: `npm run build:web`
- Publish directory: `dist`
- Node version: 20
- Expo web output: single-page app
- Netlify SPA fallback: `public/_redirects`

## Requirements for actual live messages

1. Create/choose a Supabase project (or another hosted backend) owned by you.
2. Configure real user authentication; the current owner login is device-local and is not sufficient to authorize remote conversations.
3. Create a messages table with conversation membership checks, row-level security (RLS), and Realtime enabled.
4. Wire the app's chat screen to authenticated reads/inserts and a Realtime subscription. Only members of a conversation may read or send its messages.
5. Add only the public project URL and publishable/anon key as Expo public environment variables. Never put a service-role key, database password, Meta app secret, or JWT signing secret in the client or ZIP.
6. Configure allowed origins/redirect URLs for `https://fabulous-lolly-a074b1.netlify.app`, test two separate accounts on two devices, and verify messages are delivered, persisted, and isolated between conversations.
7. Add abuse controls, blocking/reporting, retention/deletion, privacy policy, and account deletion before public launch.

## Why this is not silently enabled

No backend project URL, public client key, database, or authenticated user model was included in the source package. Guessing those values or using an insecure shared public channel would risk exposing messages. Live messaging must not be marked complete until the backend is configured and a two-device test passes.

## Deploy

Upload this project to the Git repository connected to Netlify and deploy. If Netlify is not Git-connected, build with `npm install` and `npm run build:web`, then deploy the generated `dist/` folder. Confirm the production URL after deployment.
